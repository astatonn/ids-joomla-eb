DROP TABLE IF EXISTS `#__aniversariantes_`;
