DROP TABLE IF EXISTS `#__pagtesouro_servicos`;
DROP TABLE IF EXISTS `#__pagtesouro_uasgs`;