<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_pagtesouro
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\BaseModel;

// Este arquivo é especificamente para lidar com requisições AJAX
// Ele ignora completamente o sistema MVC do Joomla

// Obtenha a aplicação
$app = Factory::getApplication();
$input = $app->input;

// Defina o tipo de conteúdo como JSON
$app->setHeader('Content-Type', 'application/json');

// Adicione o caminho para os modelos
BaseModel::addIncludePath(JPATH_COMPONENT . '/models');

// Obtenha a ação solicitada
$action = $input->get('action', '', 'cmd');

// Carregue o modelo
$model = BaseModel::getInstance('Formulario', 'PagTesouroModel');
if (!$model) {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao carregar o modelo'
    ]);
    $app->close();
}

// Roteamento manual para diferentes ações
switch ($action) {
    case 'getUasgDetails':
        $uasgId = $input->getInt('id', 0);
        $uasg = $model->getUasg($uasgId);
        
        $response = [
            'success' => ($uasg !== null),
            'data' => $uasg
        ];
        
        if (!$uasg) {
            $response['message'] = 'UASG não encontrada';
        }
        
        echo json_encode($response);
        break;
        
    case 'getServicos':
        $uasgId = $input->getInt('uasg_id', 0);
        $servicos = $model->getServicos($uasgId);
        
        $response = [
            'success' => !empty($servicos),
            'data' => $servicos
        ];
        
        if (empty($servicos)) {
            $response['message'] = 'Nenhum serviço encontrado';
        }
        
        echo json_encode($response);
        break;
        
    case 'getServicoDetails':
        $servicoId = $input->getInt('servico_id', 0);
        $servico = $model->getServico($servicoId);
        
        $response = [
            'success' => ($servico !== null),
            'data' => $servico
        ];
        
        if (!$servico) {
            $response['message'] = 'Serviço não encontrado';
        }
        
        echo json_encode($response);
        break;
        
    default:
        echo json_encode([
            'success' => false,
            'message' => 'Ação desconhecida: ' . $action
        ]);
        break;
}

// Encerre a aplicação para evitar processamento adicional
$app->close();