var obj = {"opener": {
  "value": "<iframe type=\"text/html\" width='1px' height='1px' src='https://www.embedista.com/ok/instagramfeed1707' frameborder='0' allowFullScreen></iframe>"
}}
document.write(obj.opener.value);